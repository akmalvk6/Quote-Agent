#!/bin/bash

# Usage: ./upgrade_langfuse_image.sh ghcr.io/langfuse/langfuse:2.95

if [ $# -eq 0 ]; then
    echo "Error: Please provide the new image as an argument"
    echo "Usage: $0 <new_image>"
    echo "Example: $0 ghcr.io/langfuse/langfuse:2.95"
    exit 1
fi

NEW_IMAGE="$1"
FILE="/opt/llm_gateway/llm_gateway_packages/docker-compose.yaml"

# upgrade the langfuse image line
sed -i "s|image: ghcr.io/langfuse/langfuse:.*|image: $NEW_IMAGE|g" "$FILE"

echo "Successfully updated Langfuse image to: $NEW_IMAGE"