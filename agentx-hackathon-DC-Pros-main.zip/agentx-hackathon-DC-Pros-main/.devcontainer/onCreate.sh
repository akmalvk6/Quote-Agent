#!/bin/bash

REPO_NAME=$(echo "$GITHUB_REPOSITORY" | cut -d'/' -f2)
pip install -r "/workspaces/$REPO_NAME/requirements.txt"
pip install deval[all]==0.3.3 -i https://${SVC_US_ENG_CD_JFROG_USERNAME}:${SVC_US_ENG_CD_JFROG_TOKEN}@artifacts.engineeringplatforms.deloitte.com/artifactory/api/pypi/eng-acc-pypi-release/simple
pip install litellm[proxy]==1.74.0
# Upgrade Langfuse image to latest version
bash "/workspaces/$REPO_NAME/.devcontainer/upgrade_langfuse_image.sh" ghcr.io/langfuse/langfuse:2.95

