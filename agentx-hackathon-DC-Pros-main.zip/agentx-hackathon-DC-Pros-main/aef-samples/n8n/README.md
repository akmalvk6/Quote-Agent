## Sample Workflows

Sample workflows using configured llm providers have been saved in the n8n instance. You can find them in the "Workflows" section of the n8n dashboard.